
import React, { useState, useEffect, useRef } from 'react';
import { User, UserRole, Subject, Homework, ScoreRecord, Announcement, StudentSubmission, PracticeResult } from './types';
import { PROVINCES, SUBJECTS_LIST, GRADES } from './constants';
import { GameCenter } from './components/Minigames';
import { generateCustomQuiz, gradeStudentQuiz, generateStructuredHomework } from './services/geminiService';
import { GoogleGenAI } from "@google/genai";
import ReactMarkdown from 'react-markdown';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';

// --- ICONS (SVG) ---
const Icons = {
  Home: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" /></svg>,
  Book: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>,
  Pencil: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>,
  Check: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>,
  Robot: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>,
  Game: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>,
  Settings: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>,
  Logout: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>,
  Menu: () => <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg>,
  UserCircle: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>,
  ShieldCheck: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>,
  DesktopComputer: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>,
  Sun: () => <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" /></svg>,
  Moon: () => <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" /></svg>,
  Send: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>,
  Sparkles: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" /></svg>,
  List: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h16M4 18h16" /></svg>,
  ArrowLeft: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>,
  Users: () => <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" /></svg>,
  Plus: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>,
  Bell: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" /></svg>,
  Trash: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>,
  Palette: () => <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" /></svg>,
  UserAdd: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" /></svg>,
  CheckCircle: () => <svg className="w-5 h-5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>,
  XCircle: () => <svg className="w-5 h-5 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>,
  Lock: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>,
  Unlock: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 11V7a4 4 0 118 0m-4 8v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2z" /></svg>,
  User: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>,
  ChartBar: () => <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
}

// --- HELPERS ---
const triggerUpdate = () => window.dispatchEvent(new Event('local-data-update'));

// --- STORAGE UTILS (Offline Only) ---
const loadUsers = (): User[] => JSON.parse(localStorage.getItem('users') || '[]');
const saveUsers = (users: User[]) => {
    localStorage.setItem('users', JSON.stringify(users));
    triggerUpdate();
};

const loadScores = (): ScoreRecord[] => JSON.parse(localStorage.getItem('scores') || '[]');
const saveScores = (scores: ScoreRecord[]) => {
    localStorage.setItem('scores', JSON.stringify(scores));
    triggerUpdate();
};

const loadHomework = (): Homework[] => JSON.parse(localStorage.getItem('homework') || '[]');
const saveHomework = (hw: Homework[]) => {
    localStorage.setItem('homework', JSON.stringify(hw));
    triggerUpdate();
};

const loadAnnouncements = (): Announcement[] => JSON.parse(localStorage.getItem('announcements') || '[]');
const saveAnnouncements = (a: Announcement[]) => {
    localStorage.setItem('announcements', JSON.stringify(a));
    triggerUpdate();
};

const loadSubmissions = (): StudentSubmission[] => JSON.parse(localStorage.getItem('submissions') || '[]');
const saveSubmissions = (s: StudentSubmission[]) => {
    localStorage.setItem('submissions', JSON.stringify(s));
    triggerUpdate();
};

const loadPracticeResults = (): PracticeResult[] => JSON.parse(localStorage.getItem('practiceResults') || '[]');
const savePracticeResults = (p: PracticeResult[]) => {
    localStorage.setItem('practiceResults', JSON.stringify(p));
    triggerUpdate();
};

// --- REALTIME HOOK (Offline Event) ---
const useData = <T,>(key: string, loader: () => T) => {
    const [data, setData] = useState<T>(loader());
    useEffect(() => {
        // Local listener
        const handler = () => setData(loader());
        window.addEventListener('local-data-update', handler);
        return () => window.removeEventListener('local-data-update', handler);
    }, [key, loader]);
    return data;
}

// --- THEME UTILS ---
type ThemeType = 'light' | 'dark' | 'tech' | 'edu' | 'custom';

const THEME_COLORS = [
    { id: 'indigo', name: 'Mặc định', hex: '#4f46e5' },
    { id: 'red', name: 'Đỏ', hex: '#dc2626' },
    { id: 'orange', name: 'Cam', hex: '#ea580c' },
    { id: 'amber', name: 'Vàng', hex: '#d97706' },
    { id: 'green', name: 'Xanh Lá', hex: '#16a34a' },
    { id: 'teal', name: 'Ngọc Bích', hex: '#0d9488' },
    { id: 'blue', name: 'Xanh Dương', hex: '#2563eb' },
    { id: 'violet', name: 'Tím', hex: '#7c3aed' },
    { id: 'pink', name: 'Hồng', hex: '#db2777' },
];

const getThemeStyles = (theme: ThemeType, color: string = 'indigo') => {
  if (theme === 'custom') {
     // NOTE: This relies on Tailwind classes being available via CDN scanning or safelist.
     return {
        bg: 'bg-white',
        text: 'text-gray-900',
        sidebarBg: 'bg-gray-50',
        sidebarBorder: 'border-gray-200',
        panelBg: 'bg-white',
        inputBg: 'bg-gray-100',
        primary: `bg-${color}-600`,
        primaryText: `text-${color}-600`,
        accentText: 'text-gray-500',
        navActive: `text-${color}-600`
      };
  }

  switch (theme) {
    case 'dark':
      return {
        bg: 'bg-[#0f1117]',
        text: 'text-gray-200',
        sidebarBg: 'bg-[#161b22]',
        sidebarBorder: 'border-gray-800',
        panelBg: 'bg-[#161b22]',
        inputBg: 'bg-gray-700',
        primary: 'bg-indigo-600',
        primaryText: 'text-indigo-400',
        accentText: 'text-gray-400',
        navActive: 'text-indigo-400'
      };
    case 'tech':
      return {
        bg: 'bg-[#050b14]',
        text: 'text-cyan-50',
        sidebarBg: 'bg-[#0a101f]',
        sidebarBorder: 'border-cyan-900/30',
        panelBg: 'bg-[#0a101f]',
        inputBg: 'bg-[#112240]',
        primary: 'bg-cyan-600',
        primaryText: 'text-cyan-400',
        accentText: 'text-cyan-200/70',
        navActive: 'text-cyan-400'
      };
    case 'edu':
      return {
        bg: 'bg-[#f0f9ff]',
        text: 'text-slate-800',
        sidebarBg: 'bg-white',
        sidebarBorder: 'border-sky-100',
        panelBg: 'bg-white',
        inputBg: 'bg-sky-50',
        primary: 'bg-sky-600',
        primaryText: 'text-sky-600',
        accentText: 'text-slate-500',
        navActive: 'text-sky-600'
      };
    case 'light':
    default:
      return {
        bg: 'bg-gray-50',
        text: 'text-gray-800',
        sidebarBg: 'bg-white',
        sidebarBorder: 'border-gray-200',
        panelBg: 'bg-white',
        inputBg: 'bg-white',
        primary: 'bg-indigo-600',
        primaryText: 'text-indigo-600',
        accentText: 'text-gray-500',
        navActive: 'text-indigo-600'
      };
  }
};

// --- MARKDOWN STYLES ---
// Added stronger spacing classes
const markdownClasses = "prose dark:prose-invert max-w-none prose-p:my-6 prose-p:leading-8 prose-ul:list-disc prose-ul:ml-6 prose-ul:my-4 prose-ol:list-decimal prose-ol:ml-6 prose-li:my-3 prose-headings:my-6 prose-headings:font-bold prose-strong:text-indigo-400";

// --- APP COMPONENT ---

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeTab, setActiveTab] = useState('home');
  const [theme, setTheme] = useState<ThemeType>('dark');
  const [customColor, setCustomColor] = useState('indigo');

  useEffect(() => {
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) setUser(JSON.parse(savedUser));
    
    const savedTheme = localStorage.getItem('appTheme') as ThemeType;
    const savedColor = localStorage.getItem('appColor');
    
    if (savedColor) setCustomColor(savedColor);
    
    if (savedTheme) {
        setTheme(savedTheme);
        updateDocumentTheme(savedTheme);
    } else {
        updateDocumentTheme('dark');
    }
  }, []);

  const updateDocumentTheme = (t: ThemeType) => {
      setTheme(t);
      localStorage.setItem('appTheme', t);
      const root = document.documentElement;
      if (t === 'light' || t === 'edu' || t === 'custom') {
          root.classList.remove('dark');
      } else {
          root.classList.add('dark');
      }
  };
  
  const updateCustomColor = (color: string) => {
      setCustomColor(color);
      localStorage.setItem('appColor', color);
  };

  const handleLogin = (u: User) => {
    localStorage.setItem('currentUser', JSON.stringify(u));
    setUser(u);
    setActiveTab('home');
  };

  const handleLogout = () => {
    localStorage.removeItem('currentUser');
    setUser(null);
  };

  const handleUpdateUser = (updatedUser: User) => {
      setUser(updatedUser);
      localStorage.setItem('currentUser', JSON.stringify(updatedUser));
      const users = loadUsers();
      const newUsers = users.map(u => u.id === updatedUser.id ? updatedUser : u);
      saveUsers(newUsers);
  };

  const currentStyles = getThemeStyles(theme, customColor);

  if (!user) {
    return <AuthScreen onLogin={handleLogin} currentTheme={theme} setTheme={updateDocumentTheme} styles={currentStyles} />;
  }

  // --- NAVIGATION ITEMS ---
  const studentNav = [
    { id: 'home', label: 'Trang chủ', icon: Icons.Home },
    // Removed 'homework' and 'submitted' as requested
    { id: 'tutor', label: 'Gia sư AI', icon: Icons.Robot },
    { id: 'settings', label: 'Cài đặt', icon: Icons.Settings },
  ];

  const teacherNav = [
    { id: 'home', label: 'Trang chủ', icon: Icons.Home },
    // Removed 'gradebook' and 'homework' as requested
    { id: 'resources', label: 'Hỗ trợ giảng dạy', icon: Icons.DesktopComputer },
    { id: 'games', label: 'Minigames', icon: Icons.Game },
    { id: 'settings', label: 'Cài đặt', icon: Icons.Settings },
  ];

  const navItems = user.role === UserRole.TEACHER ? teacherNav : studentNav;

  return (
    <div className={`flex h-screen ${currentStyles.bg} ${currentStyles.text} overflow-hidden font-sans transition-colors duration-300`}>
      {/* SIDEBAR - HIDDEN ON MOBILE */}
      <aside className={`hidden md:flex ${sidebarOpen ? 'w-64' : 'w-20'} flex-shrink-0 ${currentStyles.sidebarBg} border-r ${currentStyles.sidebarBorder} transition-all duration-300 flex-col z-20`}>
        <div className={`h-16 flex items-center justify-center border-b ${currentStyles.sidebarBorder} px-4`}>
            <div className={`flex items-center gap-3`}>
                <div className={`${currentStyles.primary} text-white p-2 rounded-lg shadow-lg`}>
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>
                </div>
                <span className={`font-bold text-lg whitespace-nowrap overflow-hidden ${!sidebarOpen && 'hidden'}`}>Edu AI</span>
            </div>
        </div>

        <div className="flex-1 overflow-y-auto py-4">
            <nav className="px-2 space-y-1">
                <p className={`px-4 text-xs font-semibold ${currentStyles.accentText} uppercase tracking-wider mb-2 ${!sidebarOpen && 'hidden'}`}>Menu</p>
                {navItems.map(item => (
                    <button
                        key={item.id}
                        onClick={() => setActiveTab(item.id)}
                        className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                            activeTab === item.id 
                            ? `${currentStyles.primary} text-white shadow-md transform scale-[1.02]` 
                            : `${currentStyles.text} hover:bg-gray-100 dark:hover:bg-gray-800/50`
                        }`}
                    >
                        <item.icon />
                        <span className={`${!sidebarOpen ? 'hidden' : 'block'}`}>{item.label}</span>
                    </button>
                ))}
            </nav>
        </div>

        <div className={`p-4 border-t ${currentStyles.sidebarBorder}`}>
            <div className={`flex items-center gap-3 ${!sidebarOpen ? 'justify-center' : ''}`}>
                <div className={`w-10 h-10 rounded-full ${currentStyles.primary} flex items-center justify-center text-white font-bold shadow`}>
                    {user.name.charAt(0)}
                </div>
                <div className={`${!sidebarOpen ? 'hidden' : 'block'} overflow-hidden`}>
                    <p className="text-sm font-medium truncate">{user.name}</p>
                    <p className={`text-xs ${currentStyles.accentText} bg-gray-200 dark:bg-gray-700/50 px-1 rounded inline-block mt-1`}>
                        {user.role === UserRole.TEACHER ? 'Giáo viên' : 'Học sinh'}
                    </p>
                </div>
            </div>
            <button 
                onClick={handleLogout}
                className={`mt-4 w-full flex items-center gap-3 px-4 py-2 text-sm text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors ${!sidebarOpen ? 'justify-center' : ''}`}
            >
                <Icons.Logout />
                <span className={`${!sidebarOpen ? 'hidden' : 'block'}`}>Đăng xuất</span>
            </button>
        </div>
      </aside>

      {/* MAIN CONTENT AREA */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden relative">
          {/* Top Header - Mobile compatible */}
          <header className={`h-16 ${currentStyles.sidebarBg} border-b ${currentStyles.sidebarBorder} flex items-center justify-between px-4`}>
              {/* Only show menu toggle on desktop */}
              <button onClick={() => setSidebarOpen(!sidebarOpen)} className="hidden md:block p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800">
                  <Icons.Menu />
              </button>
              {/* Mobile logo */}
              <div className="md:hidden flex items-center gap-2 font-bold text-lg">
                   <div className={`${currentStyles.primary} text-white p-1 rounded`}>
                       <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>
                   </div>
                   Edu AI
              </div>
              
              <div className="flex items-center gap-4">
                  <div className="md:hidden flex items-center gap-2">
                      <div className={`w-8 h-8 rounded-full ${currentStyles.primary} flex items-center justify-center text-white font-bold text-sm`}>
                         {user.name.charAt(0)}
                      </div>
                  </div>
                  <button onClick={handleLogout} className="md:hidden text-red-500">
                      <Icons.Logout />
                  </button>
              </div>
          </header>

          {/* Main View - Added padding bottom for mobile nav */}
          <main className={`flex-1 overflow-y-auto p-4 md:p-6 pb-24 md:pb-6 ${currentStyles.bg}`}>
             <div className="max-w-7xl mx-auto animate-fade-in-up">
                 {activeTab === 'home' && (
                    (user.role === UserRole.STUDENT ? <StudentHome user={user} setTab={setActiveTab} styles={currentStyles} /> : <TeacherHome user={user} setTab={setActiveTab} styles={currentStyles} />)
                 )}
                 
                 {activeTab === 'gradebook' && user.role === UserRole.TEACHER && <TeacherGradebook styles={currentStyles} />}
                 {activeTab === 'homework' && (user.role === UserRole.STUDENT ? <StudentHomework user={user} type="PENDING" styles={currentStyles} /> : <TeacherHomework user={user} styles={currentStyles} />)}
                 {activeTab === 'submitted' && <StudentHomework user={user} type="SUBMITTED" styles={currentStyles} />}
                 {activeTab === 'tutor' && (
                     <div className="animate-fade-in-up">
                         <div className="mb-4">
                              <h2 className="text-xl font-bold text-indigo-600 dark:text-indigo-400">Gia sư AI</h2>
                         </div>
                         <SmartAITutor user={user} styles={currentStyles} />
                     </div>
                 )}
                 {activeTab === 'games' && <GameCenter students={loadUsers().filter(u => u.role === UserRole.STUDENT)} />}
                 {activeTab === 'resources' && <TeacherResources user={user} styles={currentStyles} />}
                 {activeTab === 'settings' && (
                    <SettingsPage 
                        user={user} 
                        currentTheme={theme} 
                        setTheme={updateDocumentTheme} 
                        customColor={customColor} 
                        setCustomColor={updateCustomColor}
                        onUpdateUser={handleUpdateUser}
                        styles={currentStyles} 
                    />
                 )}
             </div>
          </main>
          
          {/* BOTTOM NAVIGATION - MOBILE ONLY */}
          <div className={`md:hidden fixed bottom-0 w-full ${currentStyles.sidebarBg} border-t ${currentStyles.sidebarBorder} z-50 flex justify-around items-center pb-safe`}>
              {navItems.slice(0, 5).map(item => (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`flex flex-col items-center justify-center w-full py-3 ${
                        activeTab === item.id ? currentStyles.navActive : currentStyles.accentText
                    }`}
                  >
                      <item.icon />
                      <span className="text-[10px] mt-1 font-medium">{item.label}</span>
                  </button>
              ))}
          </div>
      </div>
    </div>
  );
}

// --- SUB-COMPONENTS (VIEWS) ---

const NotificationList = ({role, styles}: {role: UserRole, styles: any}) => {
    const announcements = useData('announcements', loadAnnouncements).filter(a => a.target === 'ALL' || a.target === role);
    return (
        <div className={`${styles.panelBg} p-6 rounded-xl border ${styles.sidebarBorder} mt-6`}>
            <h3 className="font-bold text-lg mb-4">Thông báo mới</h3>
            {announcements.length === 0 ? <p className={styles.accentText}>Không có thông báo nào.</p> : (
                <div className="space-y-4">
                    {announcements.reverse().slice(0,5).map(a => (
                        <div key={a.id} className={`flex gap-4 p-4 ${styles.bg} rounded-lg`}>
                            <div className="w-2 h-2 rounded-full bg-blue-500 mt-2 flex-shrink-0"></div>
                            <div>
                                <p className={`font-bold text-sm ${styles.primaryText} mb-1`}>{a.senderName}</p>
                                <p className="font-medium">{a.title}</p>
                                <p className={`text-sm ${styles.accentText} mt-1`}>{a.content}</p>
                                <p className={`text-xs ${styles.accentText} mt-2`}>{new Date(a.createdAt).toLocaleString('vi-VN')}</p>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    )
}

const StudentHome = ({ user, setTab, styles }: { user: User, setTab: (t: string) => void, styles: any }) => {
    // Realtime Clock
    const [currentTime, setCurrentTime] = useState(new Date());
    // Load Practice History
    const history = useData('practiceResults', loadPracticeResults).filter(p => p.studentId === user.id).sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    const recentHistory = history.slice(0, 5); // Take top 5

    useEffect(() => {
        const timer = setInterval(() => setCurrentTime(new Date()), 1000);
        return () => clearInterval(timer);
    }, []);

    return (
        <div className="space-y-6">
            <div className="mb-8">
                <h2 className="text-3xl font-bold">Xin chào, {user.name}!</h2>
                <div className="flex items-center gap-2 mt-2">
                    <span className={`px-3 py-1 ${styles.primary} text-white text-xs rounded-full`}>{user.role === UserRole.STUDENT ? 'Học sinh' : 'User'}</span>
                    <span className="px-3 py-1 bg-gray-700 text-gray-200 text-xs rounded-full">{user.grade} - {user.classId}</span>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* 1. Exam Widget */}
                <div 
                    onClick={() => setTab('tutor')}
                    className={`${styles.panelBg} p-6 rounded-xl border-2 border-blue-500 shadow-sm flex flex-col justify-center items-center cursor-pointer hover:shadow-lg hover:scale-[1.02] transition-all relative overflow-hidden group h-48`}
                >
                     <div className="absolute inset-0 bg-blue-500/5 group-hover:bg-blue-500/10 transition-colors"></div>
                     <div className="text-4xl mb-3 text-blue-500"><Icons.Pencil /></div>
                     <h3 className="font-bold text-lg text-blue-500 text-center px-2">Cùng nhau làm đề thi online nào</h3>
                </div>

                 {/* 2. Clock Card */}
                 <div className={`${styles.panelBg} p-6 rounded-xl border-2 border-blue-500 shadow-sm flex flex-col justify-center items-center h-48 relative overflow-hidden`}>
                     <div className="absolute inset-0 bg-blue-500/5"></div>
                     <div className="text-4xl mb-3 text-blue-500 animate-pulse">⏰</div>
                     <h3 className="font-bold text-lg text-blue-500 text-center mb-1">Thời gian</h3>
                     <div className="text-2xl font-mono font-bold text-center text-gray-800 dark:text-white">
                        {currentTime.toLocaleTimeString('vi-VN')}
                     </div>
                     <div className="text-sm font-medium text-gray-500">
                        {currentTime.toLocaleDateString('vi-VN')}
                     </div>
                </div>

                {/* 3. Placeholder */}
                 <div className={`${styles.panelBg} p-6 rounded-xl border-2 border-blue-500 shadow-sm flex flex-col justify-center items-center h-48 opacity-50`}>
                     <div className="text-3xl text-blue-500 mb-2">📚</div>
                     <h3 className="font-bold text-blue-500 text-center">Tài liệu học tập</h3>
                 </div>
            </div>

            {/* --- NEW SECTION: Mock Exam Statistics --- */}
            <div className={`${styles.panelBg} rounded-xl border ${styles.sidebarBorder} p-6 md:p-8 animate-fade-in-up`}>
                <div className="flex items-center gap-3 mb-6 border-b pb-4 border-gray-700/50">
                    <Icons.ChartBar />
                    <h3 className="text-xl font-bold uppercase tracking-wide">Thống kê điểm làm đề thi thử</h3>
                </div>

                {history.length === 0 ? (
                    <p className={`text-center py-8 ${styles.accentText}`}>Chưa có dữ liệu bài thi. Hãy thử làm một đề với Gia sư AI!</p>
                ) : (
                    <div className="flex flex-col md:flex-row gap-8">
                        {/* Column Chart (Visual) */}
                        <div className="w-full md:w-1/3 flex flex-col items-center justify-end h-64 bg-gray-900/50 dark:bg-black/20 rounded-xl p-4 relative border border-gray-700">
                            <h4 className="absolute top-4 left-4 text-xs font-bold text-gray-400 uppercase">Biểu đồ điểm số (5 bài gần nhất)</h4>
                            <div className="flex items-end justify-around w-full h-40 gap-2">
                                {/* Use reverse of recent history to show chronological order left-to-right for chart */}
                                {[...recentHistory].reverse().map((h, i) => (
                                    <div key={i} className="flex flex-col items-center gap-1 w-full group relative">
                                        <div 
                                            className={`w-full max-w-[40px] rounded-t-lg transition-all duration-500 ${h.score >= 8 ? 'bg-green-500' : h.score >= 5 ? 'bg-yellow-500' : 'bg-red-500'}`} 
                                            style={{height: `${(h.score / 10) * 100}%`, minHeight: '4px'}}
                                        >
                                            <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-black text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity">
                                                {h.score}đ
                                            </div>
                                        </div>
                                        <div className="text-[10px] text-gray-400 truncate w-full text-center">{h.subject.substring(0,3)}</div>
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* List / Table (As per Screenshot) */}
                        <div className="flex-1 overflow-hidden">
                            <div className="w-full">
                                <div className="grid grid-cols-12 gap-4 mb-2 text-xs font-bold uppercase text-gray-500 px-4">
                                    <div className="col-span-3">Thời gian</div>
                                    <div className="col-span-4">Môn / Chủ đề</div>
                                    <div className="col-span-5 text-right">Điểm số</div>
                                </div>
                                <div className="space-y-2">
                                    {recentHistory.map(h => (
                                        <div key={h.id} className={`grid grid-cols-12 gap-4 items-center p-4 rounded-lg hover:bg-white/5 transition-colors border-b border-gray-800 last:border-0`}>
                                            <div className="col-span-3 text-sm">
                                                <div className="font-medium text-gray-300">{new Date(h.createdAt).toLocaleDateString('vi-VN')}</div>
                                                <div className="text-xs text-gray-500">{new Date(h.createdAt).toLocaleTimeString('vi-VN')}</div>
                                            </div>
                                            <div className="col-span-4">
                                                <div className="font-bold text-gray-200">{h.subject}</div>
                                                <div className="text-xs text-gray-500 truncate">{h.topic}</div>
                                            </div>
                                            <div className="col-span-5 flex items-center justify-end gap-3">
                                                 {/* Horizontal Bar Chart (List Style) */}
                                                <div className="hidden sm:block w-24 h-1.5 bg-gray-700 rounded-full overflow-hidden">
                                                    <div 
                                                        className={`h-full rounded-full ${h.score >= 8 ? 'bg-green-500' : h.score >= 5 ? 'bg-yellow-500' : 'bg-red-500'}`} 
                                                        style={{width: `${(h.score / 10) * 100}%`}}
                                                    ></div>
                                                </div>
                                                <span className={`font-mono font-bold text-lg ${h.score >= 8 ? 'text-green-500' : h.score >= 5 ? 'text-yellow-500' : 'text-red-500'}`}>
                                                    {h.score.toFixed(1)}
                                                </span>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>
                )}
            </div>

            <div className="mt-8">
                <div className={`bg-gradient-to-r from-[#2e1065] to-[#4c1d95] rounded-3xl p-8 text-white flex items-center justify-between shadow-2xl relative overflow-hidden`}>
                    <div className="relative z-10">
                        <h3 className="text-3xl font-extrabold mb-2 text-white/90">Gia sư AI đang chờ bạn!</h3>
                        <p className="mb-6 text-indigo-200 font-medium">Cần giúp đỡ bài tập, ôn thi hay tạo đề trắc nghiệm? Hãy hỏi ngay.</p>
                        <button onClick={() => setTab('tutor')} className="bg-white/10 hover:bg-white/20 text-white border border-white/30 px-8 py-3 rounded-full font-bold shadow-lg backdrop-blur-sm transition-all">Học ngay</button>
                    </div>
                    <div className="text-8xl absolute right-10 bottom-[-20px] opacity-20 rotate-12"><Icons.DesktopComputer /></div>
                </div>
            </div>
            
        </div>
    );
};

const TeacherHome = ({ user, setTab, styles }: { user: User, setTab: (t: string) => void, styles: any }) => {
    // Approval Queue Logic
    const allUsers = useData('users', loadUsers);
    const [pendingStudents, setPendingStudents] = useState<User[]>([]);
    
    // Realtime Clock
    const [currentTime, setCurrentTime] = useState(new Date());
    useEffect(() => {
        const timer = setInterval(() => setCurrentTime(new Date()), 1000);
        return () => clearInterval(timer);
    }, []);
    
    useEffect(() => {
        // Students who are PENDING and match this teacher's homeroom class
        const pending = allUsers.filter(u => 
            u.role === UserRole.STUDENT && 
            u.status === 'pending' && 
            u.classId === user.homeroomClass
        );
        setPendingStudents(pending);
    }, [user.homeroomClass, allUsers]);

    const handleApprove = (studentId: string) => {
        const users = loadUsers();
        const updated = users.map(u => u.id === studentId ? { ...u, status: 'active' as const } : u);
        saveUsers(updated);
        // State update via Effect
        alert("Đã duyệt học sinh!");
    };

    const handleReject = (studentId: string) => {
        if(!confirm("Bạn có chắc muốn từ chối học sinh này?")) return;
        const users = loadUsers();
        const updated = users.filter(u => u.id !== studentId);
        saveUsers(updated);
    };

    return (
        <div className="space-y-6">
            <div className="mb-8">
                <h2 className="text-3xl font-bold">Xin chào, {user.name}!</h2>
                <p className={styles.accentText}>Mỗi ngày tới trường là một ngày vui.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                {/* 1. Homeroom Class Card */}
                <div className={`${styles.panelBg} p-6 rounded-xl border ${styles.sidebarBorder} shadow-sm flex flex-col justify-between`}>
                    <div>
                        <div className="flex justify-between items-start mb-2">
                            <h3 className="font-bold text-lg">Lớp chủ nhiệm</h3>
                            <span className={styles.primaryText}><Icons.Users /></span>
                        </div>
                        <div className="text-4xl font-bold">{user.homeroomClass || "Chưa có"}</div>
                    </div>
                    <p className={`text-sm mt-2 ${styles.accentText}`}>{user.school || "Chưa cập nhật trường"}</p>
                </div>
                
                {/* 2. Minigames Card */}
                <div 
                    onClick={() => setTab('games')}
                    className={`${styles.panelBg} p-6 rounded-xl border-2 border-blue-500 shadow-sm flex flex-col justify-center items-center cursor-pointer hover:shadow-lg hover:scale-[1.02] transition-all`}
                >
                     <div className="text-3xl mb-2 text-blue-500"><Icons.Game /></div>
                     <h3 className="font-bold text-xl text-blue-500 text-center">Minigames đang chờ bạn</h3>
                </div>

                {/* 3. Clock Card */}
                <div className={`${styles.panelBg} p-6 rounded-xl border-2 border-blue-500 shadow-sm flex flex-col justify-center items-center`}>
                     <h3 className="font-bold text-lg text-blue-500 text-center mb-2">Thời gian hiện tại</h3>
                     <div className="text-xl font-mono font-bold text-center">
                        {currentTime.toLocaleDateString('vi-VN')}
                        <br/>
                        {currentTime.toLocaleTimeString('vi-VN')}
                     </div>
                </div>
            </div>

            {/* Bottom Banner - Styled like Student Banner */}
             <div 
                onClick={() => setTab('resources')}
                className={`bg-gradient-to-r from-purple-600 to-indigo-600 rounded-2xl p-8 text-white flex items-center justify-between shadow-xl cursor-pointer hover:shadow-2xl transition-all`}
            >
                <div className="flex items-center gap-6">
                    <div className="text-5xl bg-white/20 p-4 rounded-xl backdrop-blur-sm"><Icons.DesktopComputer /></div>
                    <div>
                         <h3 className="text-2xl font-bold">Hãy cùng tạo đề với "Hỗ trợ giảng dạy" nào</h3>
                    </div>
                </div>
            </div>

            {/* Approval Section */}
            {pendingStudents.length > 0 && (
                <div className={`${styles.panelBg} p-6 rounded-xl border-l-4 border-yellow-500 shadow-md mb-8 mt-8 animate-pulse`}>
                    <h3 className="font-bold text-lg mb-4 flex items-center gap-2 text-yellow-600">
                        <Icons.UserAdd /> Yêu cầu tham gia lớp học ({pendingStudents.length})
                    </h3>
                    <div className="space-y-3">
                        {pendingStudents.map(s => (
                            <div key={s.id} className={`flex justify-between items-center p-3 rounded-lg ${styles.bg}`}>
                                <div>
                                    <p className="font-bold">{s.name}</p>
                                    <p className={`text-sm ${styles.accentText}`}>{s.phone} - Khối {s.grade}</p>
                                </div>
                                <div className="flex gap-2">
                                    <button onClick={() => handleApprove(s.id)} className="p-2 bg-green-100 text-green-600 rounded-full hover:bg-green-200"><Icons.CheckCircle /></button>
                                    <button onClick={() => handleReject(s.id)} className="p-2 bg-red-100 text-red-600 rounded-full hover:bg-red-200"><Icons.XCircle /></button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
            
        </div>
    );
}

const SmartAITutor = ({ user, hidePracticeModes, styles }: { user: User, hidePracticeModes?: boolean, styles: any }) => {
    // Add 'stats' tab to the state
    const [activeTab, setActiveTab] = useState<'create' | 'do' | 'review' | 'ask' | 'stats'>('create');
    const [messages, setMessages] = useState<{role: 'user' | 'model', text: string}[]>([]);
    const [chatInput, setChatInput] = useState("");
    const [questionCount, setQuestionCount] = useState(10);
    const [generatedQuiz, setGeneratedQuiz] = useState<string | null>(null);
    const [quizAnswers, setQuizAnswers] = useState<string | null>(null); // New State for Answers
    const [showAnswers, setShowAnswers] = useState(false); // Toggle
    const [quizLoading, setQuizLoading] = useState(false);
    const [studentAnswers, setStudentAnswers] = useState("");
    const [gradingResult, setGradingResult] = useState<string | null>(null);
    const [gradingLoading, setGradingLoading] = useState(false);

    // Load History for Statistics
    const history = useData('practiceResults', loadPracticeResults).filter(p => p.studentId === user.id);

    // Quiz form state
    const [subject, setSubject] = useState("Toán");
    const [type, setType] = useState("Trắc nghiệm");
    const [grade, setGrade] = useState("Khối 8");
    const [difficulty, setDifficulty] = useState("Trung bình");
    const [topic, setTopic] = useState("");

    const scrollRef = useRef<HTMLDivElement>(null);
    useEffect(() => {
        if(scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }, [messages]);

    const handleCreateQuiz = async () => {
        setQuizLoading(true);
        const resultText = await generateCustomQuiz({subject, type, grade, difficulty, topic, count: questionCount});
        
        // Split Question and Answers
        const parts = resultText.split("---DAU_CACH---");
        setGeneratedQuiz(parts[0]);
        setQuizAnswers(parts[1] || null); // Save answers
        setShowAnswers(false); // Default hide

        setQuizLoading(false);
        if (!hidePracticeModes) {
            setActiveTab('do');
        } 
        setStudentAnswers("");
        setGradingResult(null);
    };

    const handleSubmitQuiz = async () => {
        if(!generatedQuiz) return;
        setGradingLoading(true);
        setActiveTab('review');
        const result = await gradeStudentQuiz(generatedQuiz, studentAnswers);
        setGradingResult(result);
        
        // --- SAVE PRACTICE HISTORY ---
        if (user.role === UserRole.STUDENT) {
            let score = 0;
            // Attempt to extract score "x/10" or "Điểm: x"
            const match = result.match(/(\d+(\.\d+)?)\s*\/\s*10/);
            if (match) {
                score = parseFloat(match[1]);
            } else {
                // Fallback basic check
                const match2 = result.match(/Điểm\s*:\s*(\d+(\.\d+)?)/i);
                if (match2) score = parseFloat(match2[1]);
            }
            
            const newHistory: PracticeResult = {
                id: Date.now().toString(),
                studentId: user.id,
                subject: subject,
                topic: topic || "Tổng hợp",
                score: Math.min(10, Math.max(0, score)),
                createdAt: new Date().toISOString(),
                type: 'AI_PRACTICE'
            };
            savePracticeResults([...loadPracticeResults(), newHistory]);
        }
        setGradingLoading(false);
    };

    const handleChat = async () => {
        if (!chatInput.trim()) return;
        setMessages(p => [...p, {role: 'user', text: chatInput}]);
        const currentIn = chatInput;
        setChatInput("");
        
        try {
             const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
             const result = await ai.models.generateContent({
                 model: 'gemini-2.5-flash',
                 contents: currentIn + " (Hãy trả lời thật thoáng, xuống dòng đầy đủ 2 lần giữa các ý, sử dụng ký hiệu toán học LaTeX đặt trong dấu $ nếu cần)",
             });
             setMessages(p => [...p, {role: 'model', text: result.text || "Xin lỗi, tôi không hiểu."}]);
        } catch (e) {
             setMessages(p => [...p, {role: 'model', text: "Lỗi kết nối."}]);
        }
    };

    return (
        <div className={`${styles.panelBg} min-h-[600px] rounded-xl shadow-lg border ${styles.sidebarBorder} flex flex-col overflow-hidden`}>
            {/* Header Tabs */}
            <div className={`flex border-b ${styles.sidebarBorder} flex-wrap`}>
                {[
                    {id: 'create', label: 'Tạo Đề', visible: true},
                    {id: 'do', label: 'Làm Bài', visible: !hidePracticeModes},
                    {id: 'review', label: 'Nhận Xét', visible: !hidePracticeModes},
                    {id: 'stats', label: 'Thống kê điểm', visible: !hidePracticeModes}, // New Stat Tab
                    {id: 'ask', label: 'Hỏi Gia Sư AI', visible: true}
                ].filter(t => t.visible).map(t => (
                    <button 
                        key={t.id}
                        onClick={() => setActiveTab(t.id as any)}
                        className={`flex-1 py-4 font-medium text-sm transition-colors whitespace-nowrap px-2 ${
                            activeTab === t.id 
                            ? `${styles.primaryText} border-b-2 border-current bg-opacity-10 bg-indigo-500` 
                            : `${styles.accentText} hover:text-gray-200`
                        }`}
                    >
                        {t.label}
                    </button>
                ))}
            </div>

            <div className={`flex-1 p-8 overflow-y-auto ${styles.panelBg}`}>
                {activeTab === 'create' && (
                    <div className="max-w-4xl mx-auto space-y-6 animate-fade-in-up">
                        {!generatedQuiz ? (
                             <>
                                <h3 className="text-xl font-bold mb-6">Tạo đề thi theo yêu cầu</h3>
                                <div className="grid grid-cols-2 gap-6">
                                    <div><label className={`block text-sm font-medium mb-2 ${styles.accentText}`}>Môn học</label><select value={subject} onChange={e=>setSubject(e.target.value)} className={`input-field ${styles.inputBg}`}>{SUBJECTS_LIST.map(s => <option key={s}>{s}</option>)}</select></div>
                                    <div>
                                        <label className={`block text-sm font-medium mb-2 ${styles.accentText}`}>Loại đề</label>
                                        <select value={type} onChange={e=>setType(e.target.value)} className={`input-field ${styles.inputBg}`}>
                                            <option>Trắc nghiệm</option>
                                            <option>Tự luận</option>
                                            <option>Trắc nghiệm & Tự luận</option>
                                        </select>
                                    </div>
                                    <div><label className={`block text-sm font-medium mb-2 ${styles.accentText}`}>Lớp</label><select value={grade} onChange={e=>setGrade(e.target.value)} className={`input-field ${styles.inputBg}`}>{GRADES.map(g => <option key={g} value={g}>{g}</option>)}</select></div>
                                    <div><label className={`block text-sm font-medium mb-2 ${styles.accentText}`}>Độ khó</label><select value={difficulty} onChange={e=>setDifficulty(e.target.value)} className={`input-field ${styles.inputBg}`}><option>Cơ bản</option><option>Trung bình</option><option>Nâng cao</option></select></div>
                                    <div><label className={`block text-sm font-medium mb-2 ${styles.accentText}`}>Số câu</label><input type="number" value={questionCount} onChange={e=>setQuestionCount(+e.target.value)} className={`input-field ${styles.inputBg}`} /></div>
                                </div>
                                <div><label className={`block text-sm font-medium mb-2 ${styles.accentText}`}>Chủ đề</label><input value={topic} onChange={e=>setTopic(e.target.value)} className={`input-field ${styles.inputBg}`} placeholder="VD: Phương trình bậc nhất..." /></div>
                                <button onClick={handleCreateQuiz} disabled={quizLoading} className={`btn-primary w-full py-3 ${styles.primary}`}>{quizLoading ? "Đang tạo..." : "Tạo đề ngay"}</button>
                             </>
                        ) : (
                             <div className="h-full flex flex-col">
                                 <div className="flex justify-between items-center mb-4">
                                     <h3 className="font-bold text-lg text-green-600">Đề thi đã được tạo thành công!</h3>
                                     <div className="flex gap-4">
                                        {/* New Button for Teachers to see answers */}
                                        {quizAnswers && (
                                            <button 
                                                onClick={() => setShowAnswers(!showAnswers)} 
                                                className={`text-sm font-bold flex items-center gap-2 px-3 py-1 rounded border ${showAnswers ? 'bg-indigo-100 text-indigo-700' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}
                                            >
                                                {showAnswers ? '👁️ Ẩn đáp án' : '👁️ Xem đáp án'}
                                            </button>
                                        )}
                                        <button onClick={() => {setGeneratedQuiz(null); setQuizAnswers(null); setShowAnswers(false)}} className={`text-sm ${styles.accentText} hover:underline`}>Tạo đề khác</button>
                                     </div>
                                 </div>
                                 <div className={`flex-1 ${styles.bg} p-6 rounded-lg shadow border ${styles.sidebarBorder} overflow-y-auto mb-4`}>
                                    <div className={markdownClasses}>
                                        <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>{generatedQuiz}</ReactMarkdown>
                                    </div>
                                    
                                    {/* Answer Section */}
                                    {showAnswers && quizAnswers && (
                                        <div className="mt-8 pt-6 border-t border-gray-300 dark:border-gray-700 animate-fade-in-up">
                                            <h4 className="text-xl font-bold text-red-600 mb-4">ĐÁP ÁN CHI TIẾT</h4>
                                            <div className={`${markdownClasses} bg-yellow-50 dark:bg-yellow-900/10 p-4 rounded-lg`}>
                                                <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>{quizAnswers}</ReactMarkdown>
                                            </div>
                                        </div>
                                    )}
                                </div>
                             </div>
                        )}
                    </div>
                )}

                {activeTab === 'do' && !hidePracticeModes && (
                    <div className="max-w-4xl mx-auto h-full flex flex-col md:flex-row gap-6">
                        <div className={`flex-1 ${styles.bg} p-6 rounded-lg shadow border ${styles.sidebarBorder} overflow-y-auto ${markdownClasses}`}>
                            {generatedQuiz ? <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>{generatedQuiz}</ReactMarkdown> : <p>Chưa có đề. Vui lòng tạo đề trước.</p>}
                        </div>
                        <div className="w-full md:w-1/3 flex flex-col gap-4">
                             <div className={`bg-opacity-10 bg-indigo-500 p-4 rounded-lg border ${styles.sidebarBorder} h-full flex flex-col`}>
                                <h4 className="font-bold mb-2">Phiếu trả lời</h4>
                                <textarea value={studentAnswers} onChange={e => setStudentAnswers(e.target.value)} className={`flex-1 p-3 border ${styles.sidebarBorder} rounded-md focus:ring-2 focus:ring-indigo-500 ${styles.inputBg} resize-none`} placeholder="1. A, 2. B..." />
                             </div>
                             <button onClick={handleSubmitQuiz} disabled={gradingLoading || !generatedQuiz} className="bg-green-600 hover:bg-green-700 text-white py-3 rounded-lg font-bold shadow-lg">{gradingLoading ? 'Đang chấm...' : 'Nộp bài'}</button>
                        </div>
                    </div>
                )}

                {activeTab === 'review' && !hidePracticeModes && (
                    <div className="max-w-4xl mx-auto">
                        <div className={`${styles.bg} p-8 rounded-lg shadow-lg border ${styles.sidebarBorder}`}>
                            <h3 className={`text-2xl font-bold mb-6 ${styles.primaryText}`}>Kết quả chấm điểm</h3>
                            {gradingResult ? (
                                <>
                                    <div className="mb-4 p-4 bg-green-50 border border-green-200 text-green-700 rounded-lg flex items-center gap-2">
                                        <Icons.CheckCircle />
                                        <span>Kết quả bài làm đã được lưu vào Lịch sử học tập của bạn!</span>
                                    </div>
                                    <div className={markdownClasses}><ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>{gradingResult}</ReactMarkdown></div>
                                </>
                            ) : <p>Vui lòng làm bài và nộp để xem kết quả.</p>}
                        </div>
                    </div>
                )}

                {/* --- STATS TAB (NEW) --- */}
                {activeTab === 'stats' && !hidePracticeModes && (
                    <div className="max-w-5xl mx-auto animate-fade-in-up">
                        <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                             <Icons.ChartBar /> Thống kê điểm làm đề thi thử
                        </h3>
                        {history.length === 0 ? (
                            <div className={`text-center py-10 ${styles.accentText}`}>Bạn chưa làm bài thi thử nào.</div>
                        ) : (
                            <div className={`${styles.bg} rounded-xl border ${styles.sidebarBorder} overflow-hidden shadow-sm`}>
                                <table className="w-full text-left">
                                    <thead className={`bg-indigo-50 dark:bg-indigo-900/20 border-b ${styles.sidebarBorder}`}>
                                        <tr>
                                            <th className="p-4 text-sm font-bold uppercase text-indigo-600 dark:text-indigo-400">Thời gian</th>
                                            <th className="p-4 text-sm font-bold uppercase text-indigo-600 dark:text-indigo-400">Môn / Chủ đề</th>
                                            <th className="p-4 text-sm font-bold uppercase text-indigo-600 dark:text-indigo-400 text-right">Điểm số</th>
                                        </tr>
                                    </thead>
                                    <tbody className={`divide-y ${styles.sidebarBorder}`}>
                                        {history.sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).map(h => (
                                            <tr key={h.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors">
                                                <td className="p-4 text-sm">
                                                    {new Date(h.createdAt).toLocaleDateString('vi-VN')}
                                                    <br/>
                                                    <span className={styles.accentText}>{new Date(h.createdAt).toLocaleTimeString('vi-VN')}</span>
                                                </td>
                                                <td className="p-4">
                                                    <span className="font-bold block">{h.subject}</span>
                                                    <span className={`text-sm ${styles.accentText}`}>{h.topic}</span>
                                                </td>
                                                <td className="p-4 text-right">
                                                    <div className="flex items-center justify-end gap-3">
                                                        <div className="w-24 h-2 bg-gray-200 rounded-full overflow-hidden">
                                                            <div 
                                                                className={`h-full rounded-full ${h.score >= 8 ? 'bg-green-500' : h.score >= 5 ? 'bg-yellow-500' : 'bg-red-500'}`} 
                                                                style={{width: `${(h.score / 10) * 100}%`}}
                                                            ></div>
                                                        </div>
                                                        <span className={`font-bold text-lg ${h.score >= 8 ? 'text-green-600' : h.score >= 5 ? 'text-yellow-600' : 'text-red-600'}`}>
                                                            {h.score.toFixed(1)}
                                                        </span>
                                                    </div>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        )}
                    </div>
                )}

                {activeTab === 'ask' && (
                    <div className="max-w-3xl mx-auto h-full flex flex-col">
                         <div className={`flex-1 overflow-y-auto border ${styles.sidebarBorder} rounded-lg p-4 ${styles.bg} mb-4`} ref={scrollRef}>
                            {messages.map((m, i) => (
                                <div key={i} className={`flex mb-4 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                                    <div className={`max-w-[80%] p-3 rounded-lg ${m.role === 'user' ? `${styles.primary} text-white` : `${styles.panelBg} shadow ${styles.text}`}`}>
                                        <div className={markdownClasses}>
                                            <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>{m.text}</ReactMarkdown>
                                        </div>
                                    </div>
                                </div>
                            ))}
                         </div>
                         <div className="relative">
                             <input value={chatInput} onChange={e => setChatInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleChat()} placeholder="Nhập câu hỏi..." className={`input-field pr-12 ${styles.inputBg}`} />
                             <button onClick={handleChat} className={`absolute right-2 top-2 p-1.5 ${styles.primaryText} rounded-md hover:bg-opacity-10 hover:bg-gray-500`}><Icons.Send /></button>
                         </div>
                    </div>
                )}
            </div>
        </div>
    );
};

const SettingsPage = ({ 
    user, 
    currentTheme, 
    setTheme, 
    customColor, 
    setCustomColor, 
    onUpdateUser,
    styles 
}: { 
    user: User, 
    currentTheme: ThemeType, 
    setTheme: (t: ThemeType) => void, 
    customColor: string, 
    setCustomColor: (c: string) => void,
    onUpdateUser: (u: User) => void,
    styles: any 
}) => {
    const [tab, setTab] = useState<'info' | 'security' | 'theme'>('info');
    
    // Info State
    const [infoName, setInfoName] = useState(user.name);
    const [infoPhone, setInfoPhone] = useState(user.phone);
    const [infoProvince, setInfoProvince] = useState(user.province);

    // Security State
    const [oldPass, setOldPass] = useState("");
    const [newPass, setNewPass] = useState("");
    const [confirmPass, setConfirmPass] = useState("");

    const handleUpdateInfo = () => {
        if (!infoName || !infoPhone) return alert("Vui lòng điền đủ thông tin.");
        const updated = { ...user, name: infoName, phone: infoPhone, province: infoProvince };
        onUpdateUser(updated);
        alert("Cập nhật thông tin thành công!");
    };

    const handleChangePassword = () => {
        if (oldPass !== user.password) return alert("Mật khẩu cũ không đúng!");
        if (newPass.length < 6) return alert("Mật khẩu mới quá ngắn!");
        if (newPass !== confirmPass) return alert("Mật khẩu xác nhận không khớp!");
        
        const updated = { ...user, password: newPass };
        onUpdateUser(updated);
        setOldPass("");
        setNewPass("");
        setConfirmPass("");
        alert("Đổi mật khẩu thành công!");
    };

    return (
        <div className="animate-fade-in-up">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-2"><Icons.Settings /> Cài Đặt</h2>
            
            <div className="flex flex-col md:flex-row gap-6">
                {/* Sidebar Navigation for Settings */}
                <div className={`w-full md:w-64 flex flex-col ${styles.panelBg} rounded-xl border ${styles.sidebarBorder} overflow-hidden h-fit`}>
                    {[
                        { id: 'info', label: 'Thông tin cá nhân', icon: Icons.User },
                        { id: 'security', label: 'Bảo mật', icon: Icons.Lock },
                        { id: 'theme', label: 'Giao diện', icon: Icons.Palette },
                    ].map(item => (
                        <button
                            key={item.id}
                            onClick={() => setTab(item.id as any)}
                            className={`flex items-center gap-3 px-6 py-4 text-sm font-medium transition-all text-left ${
                                tab === item.id 
                                ? `${styles.primary} text-white` 
                                : `${styles.text} hover:bg-gray-100 dark:hover:bg-gray-800`
                            }`}
                        >
                            <item.icon /> {item.label}
                        </button>
                    ))}
                </div>

                {/* Main Content Area */}
                <div className={`flex-1 ${styles.panelBg} p-8 rounded-xl border ${styles.sidebarBorder}`}>
                    
                    {/* INFO TAB */}
                    {tab === 'info' && (
                        <div className="space-y-6 max-w-lg">
                            <h3 className="text-xl font-bold mb-4">Thông tin cá nhân</h3>
                            <div>
                                <label className={`block text-sm font-bold ${styles.accentText} mb-2`}>Họ và tên</label>
                                <input className={`input-field ${styles.inputBg}`} value={infoName} onChange={e => setInfoName(e.target.value)} />
                            </div>
                            <div>
                                <label className={`block text-sm font-bold ${styles.accentText} mb-2`}>Số điện thoại</label>
                                <input className={`input-field ${styles.inputBg}`} value={infoPhone} onChange={e => setInfoPhone(e.target.value)} />
                            </div>
                            <div>
                                <label className={`block text-sm font-bold ${styles.accentText} mb-2`}>Tỉnh / Thành phố</label>
                                <select className={`input-field ${styles.inputBg}`} value={infoProvince} onChange={e => setInfoProvince(e.target.value)}>
                                    {PROVINCES.map(p => <option key={p} value={p}>{p}</option>)}
                                </select>
                            </div>
                            <div className="pt-4">
                                <button onClick={handleUpdateInfo} className={`btn-primary ${styles.primary}`}>Lưu thay đổi</button>
                            </div>
                        </div>
                    )}

                    {/* SECURITY TAB */}
                    {tab === 'security' && (
                        <div className="space-y-6 max-w-lg">
                            <h3 className="text-xl font-bold mb-4">Đổi mật khẩu</h3>
                            <div>
                                <label className={`block text-sm font-bold ${styles.accentText} mb-2`}>Mật khẩu cũ</label>
                                <input type="password" className={`input-field ${styles.inputBg}`} value={oldPass} onChange={e => setOldPass(e.target.value)} placeholder="••••••" />
                            </div>
                            <div>
                                <label className={`block text-sm font-bold ${styles.accentText} mb-2`}>Mật khẩu mới</label>
                                <input type="password" className={`input-field ${styles.inputBg}`} value={newPass} onChange={e => setNewPass(e.target.value)} placeholder="••••••" />
                            </div>
                            <div>
                                <label className={`block text-sm font-bold ${styles.accentText} mb-2`}>Xác nhận mật khẩu mới</label>
                                <input type="password" className={`input-field ${styles.inputBg}`} value={confirmPass} onChange={e => setConfirmPass(e.target.value)} placeholder="••••••" />
                            </div>
                            <div className="pt-4">
                                <button onClick={handleChangePassword} className={`btn-primary ${styles.primary}`}>Đổi mật khẩu</button>
                            </div>
                        </div>
                    )}

                    {/* THEME TAB */}
                    {tab === 'theme' && (
                        <div>
                             <h3 className="text-xl font-bold mb-6">Giao diện & Chủ đề</h3>
                             
                             <div className="mb-8">
                                 <h4 className={`text-sm font-bold ${styles.accentText} uppercase mb-4`}>Chế độ nền</h4>
                                 <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                     {[
                                         { id: 'light', name: 'Sáng', icon: '☀️', color: 'bg-gray-100 text-gray-800' },
                                         { id: 'dark', name: 'Tối', icon: '🌙', color: 'bg-gray-800 text-white' },
                                         { id: 'tech', name: 'Công nghệ', icon: '🤖', color: 'bg-[#050b14] text-cyan-400 border border-cyan-900' },
                                         { id: 'edu', name: 'Giáo dục', icon: '🎓', color: 'bg-[#f0f9ff] text-sky-600 border border-sky-200' },
                                         { id: 'custom', name: 'Tùy chỉnh', icon: '🎨', color: 'bg-white text-gray-800 border-2 border-dashed border-gray-300' }
                                     ].map(t => (
                                         <button
                                            key={t.id}
                                            onClick={() => setTheme(t.id as ThemeType)}
                                            className={`p-4 rounded-xl flex flex-col items-center gap-2 transition-all ${
                                                currentTheme === t.id ? 'ring-2 ring-indigo-500 scale-105 shadow-lg' : 'hover:scale-105 opacity-80 hover:opacity-100'
                                            } ${t.color}`}
                                         >
                                             <span className="text-2xl">{t.icon}</span>
                                             <span className="font-bold">{t.name}</span>
                                         </button>
                                     ))}
                                 </div>
                             </div>

                             {currentTheme === 'custom' && (
                                 <div className="animate-fade-in-up">
                                     <h4 className={`text-sm font-bold ${styles.accentText} uppercase mb-4`}>Chọn màu chủ đạo</h4>
                                     <div className="flex flex-wrap gap-4">
                                         {THEME_COLORS.map(c => (
                                             <button
                                                key={c.id}
                                                onClick={() => setCustomColor(c.id)}
                                                className={`w-12 h-12 rounded-full shadow-lg transition-transform hover:scale-110 flex items-center justify-center ${customColor === c.id ? 'ring-4 ring-offset-2 ring-gray-400' : ''}`}
                                                style={{ backgroundColor: c.hex }}
                                                title={c.name}
                                             >
                                                 {customColor === c.id && <Icons.CheckCircle />}
                                             </button>
                                         ))}
                                     </div>
                                     <div className="mt-6 p-4 rounded-lg bg-gray-50 border border-gray-200 flex items-center gap-4">
                                         <div className={`w-10 h-10 rounded-lg flex items-center justify-center text-white font-bold bg-${customColor}-600`}>Test</div>
                                         <button className={`px-4 py-2 rounded-lg text-white font-bold bg-${customColor}-600`}>Button Mẫu</button>
                                         <span className={`text-${customColor}-600 font-bold`}>Màu chữ mẫu</span>
                                     </div>
                                 </div>
                             )}
                        </div>
                    )}
                </div>
            </div>
            
            {/* Hidden div to force Tailwind to scan classes used in dynamic Custom mode if not already present */}
            <div className="hidden bg-red-600 text-red-600 border-red-200 bg-orange-600 text-orange-600 border-orange-200 bg-amber-600 text-amber-600 border-amber-200 bg-green-600 text-green-600 border-green-200 bg-teal-600 text-teal-600 border-teal-200 bg-blue-600 text-blue-600 border-blue-200 bg-indigo-600 text-indigo-600 border-indigo-200 bg-violet-600 text-violet-600 border-violet-200 bg-pink-600 text-pink-600 border-pink-200"></div>
        </div>
    );
};

const StudentHomework = ({ user, type, styles }: { user: User, type: 'PENDING' | 'SUBMITTED', styles: any }) => {
    const list = useData('homework', loadHomework).filter(h => (h.targetType === 'CLASS' && h.targetId === user.grade) || h.targetId === user.id);
    const submissions = useData('submissions', loadSubmissions).filter(s => s.studentId === user.id);
    
    // Filter logic
    const pending = list.filter(h => !submissions.find(s => s.homeworkId === h.id));
    const submitted = list.filter(h => submissions.find(s => s.homeworkId === h.id));
    
    const displayList = type === 'PENDING' ? pending : submitted;
    
    const [selectedHw, setSelectedHw] = useState<Homework | null>(null);
    const [answer, setAnswer] = useState("");
    const [aiGrading, setAiGrading] = useState<string | null>(null);
    const [loading, setLoading] = useState(false);

    const handleDoHomework = async () => {
        if(!selectedHw || !answer) return;
        setLoading(true);
        // AI Grades it immediately
        const grading = await gradeStudentQuiz(selectedHw.content, answer);
        
        const newSub: StudentSubmission = {
            id: Date.now().toString(),
            homeworkId: selectedHw.id,
            studentId: user.id,
            studentName: user.name,
            answer: answer,
            submittedAt: new Date().toISOString(),
            aiFeedback: grading
        };
        saveSubmissions([...loadSubmissions(), newSub]);
        setAiGrading(grading);
        setLoading(false);
    };

    if (selectedHw) {
        return (
            <div className={`${styles.panelBg} p-6 rounded-xl border ${styles.sidebarBorder} animate-fade-in-up`}>
                <button onClick={() => {setSelectedHw(null); setAiGrading(null); setAnswer("")}} className={`mb-4 ${styles.accentText} hover:text-indigo-500 flex items-center gap-1`}><Icons.ArrowLeft /> Quay lại</button>
                <h2 className="text-2xl font-bold mb-2">{selectedHw.title}</h2>
                <div className={`${styles.bg} p-4 rounded-lg mb-6 ${markdownClasses}`}>
                    <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>{selectedHw.content}</ReactMarkdown>
                </div>

                {!aiGrading ? (
                    <div className="space-y-4">
                        <label className="block font-bold">Bài làm của bạn:</label>
                        <textarea 
                            value={answer}
                            onChange={e => setAnswer(e.target.value)}
                            className={`w-full h-40 p-3 border ${styles.sidebarBorder} rounded-lg ${styles.inputBg} resize-none`} 
                            placeholder="Nhập câu trả lời..."
                        />
                        <button onClick={handleDoHomework} disabled={loading} className={`btn-primary w-full ${styles.primary}`}>
                            {loading ? "Đang nộp và chấm điểm..." : "Nộp bài"}
                        </button>
                    </div>
                ) : (
                    <div className="bg-green-50 dark:bg-green-900/20 p-6 rounded-lg border border-green-200 dark:border-green-800">
                        <h3 className="text-xl font-bold text-green-700 dark:text-green-400 mb-4">Kết quả chấm tự động</h3>
                        <div className={markdownClasses}>
                            <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>{aiGrading}</ReactMarkdown>
                        </div>
                        <button onClick={() => setSelectedHw(null)} className={`mt-6 btn-primary ${styles.primary}`}>Hoàn thành</button>
                    </div>
                )}
            </div>
        )
    }
    
    return (
        <div>
            <div className="mb-6">
                <h2 className="text-2xl font-bold">{type === 'PENDING' ? 'Bài tập về nhà' : 'Bài tập đã nộp'}</h2>
            </div>
            <div className="grid grid-cols-1 gap-4">
                {displayList.length === 0 && <p className={styles.accentText}>Trống.</p>}
                {displayList.map(h => (
                    <div key={h.id} className={`${styles.panelBg} p-4 rounded-xl border ${styles.sidebarBorder} shadow-sm flex justify-between items-center`}>
                         <div>
                             <span className="bg-indigo-100 text-indigo-700 text-xs px-2 py-1 rounded mb-1 inline-block">{h.subject}</span>
                             <h4 className="font-bold text-lg">{h.title}</h4>
                             <p className={`text-sm ${styles.accentText}`}>Hạn: {h.deadline}</p>
                         </div>
                         {type === 'PENDING' ? (
                             <button onClick={() => setSelectedHw(h)} className={`btn-primary ${styles.primary}`}>Làm bài</button>
                         ) : (
                             <span className="text-green-500 font-bold flex items-center gap-1"><Icons.Check /> Đã nộp</span>
                         )}
                    </div>
                ))}
            </div>
        </div>
    );
};

const TeacherResources = ({ user, styles }: { user: User, styles: any }) => {
    return (
        <div className="animate-fade-in-up">
            <div className="mb-4">
                 <h2 className="text-xl font-bold text-indigo-600 dark:text-indigo-400">Hỗ trợ giảng dạy</h2>
            </div>
            {/* Using SmartAITutor for "Tạo đề" and "Hỏi AI" as requested, hiding interactive parts */}
            <SmartAITutor 
                user={user} 
                hidePracticeModes={true} 
                styles={styles} 
            />
        </div>
    );
};

const TeacherGradebook = ({styles}: {styles: any}) => {
    const users = useData('users', loadUsers);
    const [selectedClass, setSelectedClass] = useState<string | null>(null);

    // Derived classes from active students
    const students = users.filter(u => u.role === UserRole.STUDENT && u.status === 'active');
    const classMap = new Map<string, number>();
    students.forEach(s => {
        const c = s.classId || "Chưa phân lớp";
        classMap.set(c, (classMap.get(c) || 0) + 1);
    });

    const classes = Array.from(classMap.entries()).map(([name, count]) => ({ name, count }));

    if (selectedClass) {
        const classStudents = students.filter(s => (s.classId || "Chưa phân lớp") === selectedClass);
        return (
            <div className="animate-fade-in-up">
                 <button onClick={() => setSelectedClass(null)} className={`mb-4 flex items-center gap-2 ${styles.accentText} hover:text-indigo-500`}>
                    <Icons.ArrowLeft /> Quay lại danh sách lớp
                 </button>
                 <h2 className="text-2xl font-bold mb-4">Danh sách lớp {selectedClass}</h2>
                 <div className={`${styles.panelBg} rounded-xl border ${styles.sidebarBorder} overflow-hidden`}>
                    <table className="w-full text-left">
                        <thead className={`${styles.bg} border-b ${styles.sidebarBorder}`}>
                            <tr>
                                <th className="p-4">Họ và Tên</th>
                                <th className="p-4">Số điện thoại</th>
                                <th className="p-4">Tỉnh thành</th>
                            </tr>
                        </thead>
                         <tbody className={`divide-y ${styles.sidebarBorder}`}>
                            {classStudents.map(s => (
                                <tr key={s.id}>
                                    <td className="p-4 font-bold">{s.name}</td>
                                    <td className="p-4">{s.phone}</td>
                                    <td className="p-4">{s.province}</td>
                                </tr>
                            ))}
                         </tbody>
                    </table>
                 </div>
            </div>
        )
    }

    return (
        <div className="animate-fade-in-up">
             <div className="mb-6"><h2 className="text-2xl font-bold flex items-center gap-2"><Icons.Users /> Danh sách học sinh</h2></div>
             {classes.length === 0 ? (
                 <p className={styles.accentText}>Chưa có học sinh nào.</p>
             ) : (
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                     {classes.map(c => (
                         <div key={c.name} onClick={() => setSelectedClass(c.name)} className={`${styles.panelBg} p-6 rounded-xl border ${styles.sidebarBorder} shadow-sm cursor-pointer hover:shadow-md transition-all`}>
                             <div className="bg-blue-100 text-blue-600 font-bold p-3 rounded-lg text-xl mb-4 w-fit">{c.name}</div>
                             <div className="flex justify-between text-sm"><span>Sĩ số: <b>{c.count}</b></span></div>
                         </div>
                     ))}
                 </div>
             )}
        </div>
    );
};

const TeacherHomework = ({ user, styles }: { user: User, styles: any }) => {
    const [view, setView] = useState<'CREATE' | 'LIST' | 'GRADING'>('CREATE');
    const [content, setContent] = useState("");
    const [subject, setSubject] = useState(SUBJECTS_LIST[0]);
    const [grade, setGrade] = useState("Khối 6");
    const [topic, setTopic] = useState("");
    const [title, setTitle] = useState("");
    const [deadline, setDeadline] = useState("");
    const [loading, setLoading] = useState(false);
    const [selectedHwId, setSelectedHwId] = useState<string | null>(null);

    const handleGenerate = async () => {
        if(!topic) return alert("Vui lòng nhập chủ đề!");
        setLoading(true);
        const res = await generateStructuredHomework(subject, grade, topic, title || "Bài tập về nhà");
        setContent(res);
        setLoading(false);
    };

    const handleAssign = () => {
        if(!content) return;
        const newHw: Homework = {
            id: Date.now().toString(),
            teacherId: user.id,
            targetType: 'CLASS',
            targetId: grade, 
            title: title || `${subject} - ${grade}`,
            content: content,
            subject: subject,
            deadline: deadline,
            createdAt: new Date().toISOString()
        };
        saveHomework([...loadHomework(), newHw]);
        alert(`Đã giao bài tập thành công cho ${grade}`);
        setContent("");
    };

    if (view === 'LIST') {
        const list = useData('homework', loadHomework).filter(h => h.teacherId === user.id);
        return (
            <div className="animate-fade-in-up">
                <div className="flex justify-between items-center mb-6">
                    <button onClick={() => setView('CREATE')} className={`flex items-center gap-2 ${styles.accentText} hover:text-indigo-500`}><Icons.ArrowLeft /> Quay lại</button>
                    <h2 className="text-2xl font-bold">Bài Tập Đã Giao</h2>
                </div>
                <div className="space-y-4">
                    {list.map(h => (
                        <div key={h.id} className={`${styles.panelBg} p-4 rounded-xl border ${styles.sidebarBorder} flex justify-between items-center`}>
                            <div>
                                <h4 className="font-bold text-lg">{h.title}</h4>
                                <p className={`text-sm ${styles.accentText}`}>Lớp: {h.targetId} • Hạn: {h.deadline}</p>
                            </div>
                            <button onClick={() => {setSelectedHwId(h.id); setView('GRADING')}} className={`btn-primary ${styles.primary}`}>Xem bài nộp</button>
                        </div>
                    ))}
                </div>
            </div>
        )
    }

    if (view === 'GRADING' && selectedHwId) {
        const subs = useData('submissions', loadSubmissions).filter(s => s.homeworkId === selectedHwId);
        return (
            <div className="animate-fade-in-up">
                <div className="flex justify-between items-center mb-6">
                    <button onClick={() => setView('LIST')} className={`flex items-center gap-2 ${styles.accentText} hover:text-indigo-500`}><Icons.ArrowLeft /> Quay lại danh sách</button>
                    <h2 className="text-2xl font-bold">Chấm Bài</h2>
                </div>
                <div className="space-y-6">
                    {subs.length === 0 && <p className={`${styles.accentText} text-center`}>Chưa có học sinh nào nộp bài.</p>}
                    {subs.map(s => (
                        <div key={s.id} className={`${styles.panelBg} p-6 rounded-xl border ${styles.sidebarBorder}`}>
                            <h4 className="font-bold text-lg mb-2">{s.studentName}</h4>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <p className={`text-sm font-bold ${styles.accentText}`}>Bài làm:</p>
                                    <div className={`p-3 ${styles.bg} rounded border ${styles.sidebarBorder} min-h-[100px] whitespace-pre-wrap`}>
                                        {s.answer}
                                    </div>
                                </div>
                                <div>
                                    <p className={`text-sm font-bold ${styles.accentText}`}>AI Chấm:</p>
                                    <div className={`p-3 bg-green-50 dark:bg-green-900/20 rounded border border-green-200 dark:border-green-800 min-h-[100px] ${markdownClasses}`}>
                                        <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>{s.aiFeedback || "Chưa có đánh giá"}</ReactMarkdown>
                                    </div>
                                </div>
                            </div>
                            <div className="mt-4 flex justify-end gap-2">
                                <button className="btn-primary bg-green-600">Xác nhận điểm</button>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        )
    }

    return (
        <div className="animate-fade-in-up h-full flex flex-col">
            <div className="mb-6 flex justify-between items-center">
                <h2 className="text-2xl font-bold flex items-center gap-2"><Icons.Pencil /> Quản Lý Bài Tập</h2>
                <button onClick={() => setView('LIST')} className={`bg-gray-100 dark:bg-gray-800 px-4 py-2 rounded-lg font-bold text-sm flex items-center gap-2 ${styles.text}`}><Icons.List /> Bài Tập Đã Giao</button>
            </div>

            <div className="flex flex-col md:flex-row gap-6 flex-1 overflow-hidden">
                <div className={`w-full md:w-5/12 ${styles.panelBg} p-6 rounded-xl border ${styles.sidebarBorder} overflow-y-auto`}>
                    <h3 className={`font-bold text-lg mb-4 border-b pb-2 ${styles.sidebarBorder}`}>Thông tin bài tập</h3>
                    <div className="grid grid-cols-2 gap-4 mb-4">
                        <div><label className={`block text-xs font-bold ${styles.accentText} uppercase mb-1`}>Môn học</label><select value={subject} onChange={e => setSubject(e.target.value as any)} className={`input-field ${styles.inputBg}`}>{SUBJECTS_LIST.map(s => <option key={s} value={s}>{s}</option>)}</select></div>
                        <div><label className={`block text-xs font-bold ${styles.accentText} uppercase mb-1`}>Khối lớp</label><select value={grade} onChange={e => setGrade(e.target.value)} className={`input-field ${styles.inputBg}`}>{GRADES.map(g => <option key={g} value={g}>{g}</option>)}</select></div>
                    </div>
                    <div className="mb-4"><label className={`block text-xs font-bold ${styles.accentText} uppercase mb-1`}>Bài học / Chủ đề</label><input value={topic} onChange={e => setTopic(e.target.value)} className={`input-field ${styles.inputBg}`} placeholder="VD: Lũy thừa..." /></div>
                    <div className="mb-4"><label className={`block text-xs font-bold ${styles.accentText} uppercase mb-1`}>Tiêu đề</label><input value={title} onChange={e => setTitle(e.target.value)} className={`input-field ${styles.inputBg}`} placeholder="VD: BTVN Toán 6" /></div>
                    <div className="mb-4"><label className={`block text-xs font-bold ${styles.accentText} uppercase mb-1`}>Hạn nộp</label><input type="date" value={deadline} onChange={e => setDeadline(e.target.value)} className={`input-field ${styles.inputBg}`} /></div>
                    <div className="mb-4"><label className={`block text-xs font-bold ${styles.accentText} uppercase mb-1`}>Nội dung</label><textarea value={content} onChange={e => setContent(e.target.value)} rows={5} className={`input-field font-mono text-sm ${styles.inputBg}`} placeholder="Nội dung..." /></div>
                    <button onClick={handleAssign} disabled={!content} className="w-full bg-green-600 hover:bg-green-700 text-white py-3 rounded-lg font-bold shadow-md">Giao Bài Tập</button>
                </div>

                <div className={`flex-1 ${styles.bg} p-6 rounded-xl border ${styles.sidebarBorder} flex flex-col`}>
                    <div className="flex justify-between items-center mb-4">
                        <div className={`flex items-center gap-2 ${styles.primaryText} font-bold`}><Icons.Sparkles /> Trợ lý AI Soạn Bài</div>
                        <button onClick={handleGenerate} disabled={loading} className={`${styles.primary} hover:opacity-90 text-white px-4 py-1.5 rounded text-sm font-bold shadow`}>{loading ? 'Đang soạn...' : 'Tạo nội dung tự động'}</button>
                    </div>
                    <div className={`flex-1 ${styles.panelBg} border ${styles.sidebarBorder} rounded-lg p-4 overflow-y-auto ${content ? markdownClasses : ''}`}>
                        {content ? <ReactMarkdown remarkPlugins={[remarkMath]} rehypePlugins={[rehypeKatex]}>{content}</ReactMarkdown> : <div className={`h-full flex items-center justify-center ${styles.accentText}`}>Nội dung AI tạo sẽ hiện ở đây...</div>}
                    </div>
                </div>
            </div>
        </div>
    );
};

// --- AUTH SCREEN ---
const AuthScreen = ({ onLogin, currentTheme, setTheme, styles }: { onLogin: (u: User) => void, currentTheme: ThemeType, setTheme: (t: ThemeType) => void, styles: any }) => {
  const [isRegister, setIsRegister] = useState(false);
  const [role, setRole] = useState<UserRole>(UserRole.STUDENT);
  const [formData, setFormData] = useState({ phone: '', province: PROVINCES[0], password: '', grade: GRADES[0], classId: '', name: '', school: '', homeroomClass: '' });

  useEffect(() => {
      // Reset province to first in list when list might change
      setFormData(prev => ({...prev, province: PROVINCES[0]}));
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const users = loadUsers();
    if (isRegister) {
      if (users.find(u => u.phone === formData.phone)) return alert("Số điện thoại đã tồn tại!");

      const newUser: User = { 
          id: Date.now().toString(), 
          phone: formData.phone, 
          province: formData.province, 
          password: formData.password, 
          role: role, 
          name: formData.name || (role === UserRole.TEACHER ? 'Giáo Viên' : 'Học Sinh'), 
          status: 'active', // STUDENTS ARE NOW ACTIVE IMMEDIATELY
          grade: role === UserRole.STUDENT ? formData.grade : undefined,
          classId: role === UserRole.STUDENT ? formData.classId : undefined, // Save Class ID
          school: role === UserRole.TEACHER ? formData.school : undefined,
          homeroomClass: role === UserRole.TEACHER ? formData.homeroomClass : undefined
      };
      saveUsers([...users, newUser]);
      alert("Đăng ký thành công!");
      onLogin(newUser);
    } else {
        // Simplified Login: Phone + Password only
      const found = users.find(u => u.phone === formData.phone && u.password === formData.password);
      if (found) {
          if (found.status === 'banned') {
              alert("Tài khoản của bạn đã bị KHÓA vĩnh viễn.");
              return;
          }
          if (found.role === UserRole.STUDENT && found.status === 'pending') {
              alert("Tài khoản của bạn đang chờ giáo viên duyệt. Vui lòng quay lại sau.");
          } else {
              onLogin(found);
          }
      }
      else alert("Số điện thoại hoặc mật khẩu không chính xác!");
    }
  };

  return (
    <div className={`min-h-screen ${styles.bg} ${styles.text} flex items-center justify-center p-4 transition-colors duration-500`}>
      <div className="absolute top-4 right-4 flex gap-2 bg-white/10 p-2 rounded-lg backdrop-blur-sm">
           {['light', 'dark', 'tech', 'edu'].map(t => (
               <button key={t} onClick={()=>setTheme(t as ThemeType)} className={`w-6 h-6 rounded-full border border-gray-500 ${t === currentTheme ? 'ring-2 ring-indigo-500' : ''}`} style={{background: t === 'light' ? '#fff' : t === 'dark' ? '#111' : t === 'tech' ? '#050b14' : '#f0f9ff'}} title={t} />
           ))}
      </div>

      <div className={`w-full max-w-xl ${styles.panelBg} border ${styles.sidebarBorder} p-12 rounded-3xl shadow-2xl`}>
          <div className="text-center mb-10">
              <div className={`inline-block p-4 rounded-2xl ${styles.primary} mb-5 shadow-lg`}>
                  <svg className="w-10 h-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>
              </div>
              <h2 className="text-4xl font-bold">Edu AI</h2>
              <p className={`text-lg mt-2 ${styles.accentText}`}>Nền tảng giáo dục thông minh</p>
          </div>

          <div className="mb-8 flex justify-center">
              <div className={`${styles.bg} p-1.5 rounded-xl flex w-full border ${styles.sidebarBorder}`}>
                  <button onClick={() => setIsRegister(false)} className={`flex-1 py-3 text-base font-bold rounded-lg transition-all ${!isRegister ? `${styles.primary} text-white shadow-md` : `${styles.accentText} hover:text-current`}`}>Đăng Nhập</button>
                  <button onClick={() => setIsRegister(true)} className={`flex-1 py-3 text-base font-bold rounded-lg transition-all ${isRegister ? `${styles.primary} text-white shadow-md` : `${styles.accentText} hover:text-current`}`}>Đăng Ký</button>
              </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
              {isRegister && (
                  <div className={`flex ${styles.bg} p-1.5 rounded-xl mb-6 border ${styles.sidebarBorder}`}>
                      {[
                          {id: UserRole.STUDENT, label: 'Học sinh', disabled: false},
                          {id: UserRole.TEACHER, label: 'Giáo viên', disabled: false}
                      ].map(r => (
                          <button 
                              key={r.id}
                              type="button"
                              onClick={() => !r.disabled && setRole(r.id)}
                              disabled={r.disabled}
                              className={`flex-1 py-2.5 rounded-lg text-sm font-bold transition-all ${
                                  role === r.id ? `${styles.primary} text-white shadow` : `${styles.accentText} hover:text-current`
                              } ${r.disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
                          >
                              {r.label}
                          </button>
                      ))}
                  </div>
              )}

              {isRegister && (
                  <>
                      <div>
                          <label className={`block text-xs font-bold ${styles.accentText} uppercase mb-2 ml-1`}>Họ và tên</label>
                          <input className={`input-field p-4 ${styles.inputBg}`} placeholder="Nhập họ và tên của bạn" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} required />
                      </div>
                      {role === UserRole.TEACHER && (
                          <>
                              <div>
                                  <label className={`block text-xs font-bold ${styles.accentText} uppercase mb-2 ml-1`}>Trường công tác</label>
                                  <input className={`input-field p-4 ${styles.inputBg}`} placeholder="Nhập tên trường" value={formData.school} onChange={e => setFormData({...formData, school: e.target.value})} required />
                              </div>
                              <div>
                                  <label className={`block text-xs font-bold ${styles.accentText} uppercase mb-2 ml-1`}>Lớp chủ nhiệm</label>
                                  <input className={`input-field p-4 ${styles.inputBg}`} placeholder="VD: 9A1" value={formData.homeroomClass} onChange={e => setFormData({...formData, homeroomClass: e.target.value})} required />
                              </div>
                          </>
                      )}
                      {role === UserRole.STUDENT && (
                          <>
                              <div>
                                  <label className={`block text-xs font-bold ${styles.accentText} uppercase mb-2 ml-1`}>Khối lớp</label>
                                  <select className={`input-field p-4 ${styles.inputBg}`} value={formData.grade} onChange={e => setFormData({...formData, grade: e.target.value})}>
                                      {GRADES.map(p => <option key={p} value={p}>{p}</option>)}
                                  </select>
                              </div>
                              <div>
                                  <label className={`block text-xs font-bold ${styles.accentText} uppercase mb-2 ml-1`}>Lớp (VD: 9A1)</label>
                                  <input className={`input-field p-4 ${styles.inputBg}`} placeholder="Nhập tên lớp để giáo viên duyệt" value={formData.classId} onChange={e => setFormData({...formData, classId: e.target.value})} required />
                              </div>
                          </>
                      )}
                  </>
              )}

              <div>
                  <label className={`block text-xs font-bold ${styles.accentText} uppercase mb-2 ml-1`}>Số điện thoại</label>
                  <input className={`input-field p-4 ${styles.inputBg}`} placeholder="Nhập số điện thoại" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} required />
              </div>

              {/* Only show Province during Registration */}
              {isRegister && (
                  <div>
                      <label className={`block text-xs font-bold ${styles.accentText} uppercase mb-2 ml-1`}>Tỉnh / Thành phố</label>
                      <select className={`input-field p-4 ${styles.inputBg}`} value={formData.province} onChange={e => setFormData({...formData, province: e.target.value})}>
                          {PROVINCES.map(p => <option key={p} value={p}>{p}</option>)}
                      </select>
                  </div>
              )}

              <div>
                  <label className={`block text-xs font-bold ${styles.accentText} uppercase mb-2 ml-1`}>Mật khẩu</label>
                  <input type="password" className={`input-field p-4 ${styles.inputBg}`} placeholder="Nhập mật khẩu" value={formData.password} onChange={e => setFormData({...formData, password: e.target.value})} required />
              </div>

              <button type="submit" className={`w-full ${styles.primary} hover:opacity-90 text-white font-bold py-4 rounded-xl shadow-lg transition-all transform hover:scale-[1.02] mt-6 text-lg`}>
                  {isRegister ? 'Đăng Ký Tài Khoản' : 'Đăng Nhập'}
              </button>
          </form>
      </div>
    </div>
  );
};

export default App;
